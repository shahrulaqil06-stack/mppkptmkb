---
name: Campus Civic Flow
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002113'
  on-tertiary-container: '#009668'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
This design system serves the student leadership body of Kolej Poly-Tech MARA Kota Bharu (MPP KPTMKB), providing a unified, mobile-first portal for announcements, voting, event registrations, welfare complaints, and academic support. 

The brand mood is authoritative yet approachable, youthful, and institutionally grounded. Drawing from the campus motto "Mesra, Prihatin, Peka" (Friendly, Caring, Attentive), the aesthetic balances collegiate structure with high-utility civic tech. 

The core style adopts **Corporate / Modern** principles fused with accessible Malaysian higher education ergonomics:
- Clean, open surfaces with high-legibility contrasts.
- Tactile, tap-friendly action targets optimized for one-handed mobile navigation on campus.
- A composed hierarchy that transforms administrative announcements and student governance into an inviting, engaging digital hub.

## Colors
The palette balances institutional gravitas with vibrant digital activity and civic growth accents:

- **Primary (`#0F172A`)**: Deep Navy Slate. Serves as the anchor for primary typography, structural headers, high-emphasis status chips, and institutional authority elements.
- **Secondary (`#2563EB`)**: Royal Blue. Drives interactive affordances, active navigation tabs, links, primary buttons, and focal student engagement states.
- **Tertiary (`#10B981`)**: Emerald Accent. Highlights student welfare wins, verified status indicators, activity badges, and positive alerts inspired by institutional vibrancy.
- **Neutral (`#F8FAFC`)**: Crisp Off-White canvas base, paired with `#FFFFFF` card layers and `#E2E8F0` sub-surface borders for clean, distraction-free daylight readability.
- **Semantic Accents**: Crisp crimson (`#EF4444`) reserved strictly for urgent college alerts and deadlines, alongside amber (`#F59E0B`) for pending submissions.

## Typography
**Inter** delivers high geometric precision, legible micro-counters, and optical clarity across small handheld viewports.

- Use `headline-lg-mobile` across mobile viewports for page-level headers to prevent unwieldy multi-line wrapping in Malay and English headlines.
- Maintain strict hierarchy between formal bulletins (utilizing `headline-md` at 600 weight) and student microcopy (`body-md` at 400 weight).
- All labels and status badges utilize medium or bold weights with uppercase tracking (`letter-spacing: 0.02em` to `0.04em`) to ensure instant glanceability under outdoor sunlight.

## Layout & Spacing
A fluid 4-column layout is adopted on mobile devices (<640px), translating to an 8-column layout on tablets (640px–1024px) and a bounded 12-column grid maxing out at 1280px on desktop screens.

- Outer canvas padding on phones enforces a standard `1rem` (`margin-mobile`), ensuring student fingers have comfortable breathing room from screen edges.
- Section-to-section flow relies on `space-lg` (`1.5rem`), while tight related elements (such as badge-to-title pairs) adhere strictly to `space-xs` and `space-sm`.
- Touch target minimums strictly enforce a 44x44px safe zone, regardless of visual padding inside compact utility cards.

## Elevation & Depth
Elevation conveys functional proximity without visual clutter. Instead of heavy dark drop shadows, the system uses multi-layered ambient light refraction:

- **Level 0 (Flat Canvas)**: `#F8FAFC` base background.
- **Level 1 (Cards & Modules)**: Pure white (`#FFFFFF`) surfaces framed with a crisp `1px` border in `#F1F5F9` and an ultra-subtle ambient drop: `0px 2px 8px -2px rgba(15, 23, 42, 0.04), 0px 4px 16px -4px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Interactive Floating Elements & Dropdowns)**: Elevated cards, quick-action sheets, and sticky navigation bars use `0px 8px 24px -4px rgba(15, 23, 42, 0.08)` paired with backdrop filters of `blur(12px)`.
- **Level 3 (Modal Dialogs & Student Voting Overlays)**: High-priority dialogue modals use `0px 20px 32px -8px rgba(15, 23, 42, 0.16)`.

## Shapes
The shape language is contemporary and soft, utilizing explicit radii to soften administrative complexity:

- Primary content cards, event showcases, and module containers strictly adhere to `rounded-2xl` (`16px / 1rem`).
- Form input fields, interactive list rows, and dropdown boxes utilize standard `rounded-lg` (`8px / 0.5rem`).
- Status chips, category filters, notification counters, and primary call-to-action pills utilize full circle radii (`rounded-full / 9999px`) to create high tactile contrast against the broader card containers.

## Components

### Buttons
- **Primary**: Solid Royal Blue (`#2563EB`) with white text, font weight 600, height 48px on mobile, full pill radius or `rounded-xl`. Active state shifts to `#1D4ED8`.
- **Secondary**: Navy Slate outline (`#0F172A`) or subtle surface tint (`#EFF6FF`) with Royal Blue text.
- **Action Floating Bar**: Bottom-anchored quick menu with sticky blurred container, hosting dual primary/secondary action triggers.

### Cards
- Bound by 16px border-radius (`rounded-2xl`), pure white fill (`#FFFFFF`), crisp `1px solid #E2E8F0` border, and Level 1 elevation shadow.
- Inner card padding strictly follows `space-md` (16px) or `space-lg` (24px) for featured student notices.

### Chips & Badges
- High-contrast pill chips (`rounded-full`) with uppercase typography (`label-sm`).
- **Academic / Admin Tag**: `#F1F5F9` background with `#0F172A` text.
- **Welfare / Approved Status**: Soft green tint (`#ECFDF5`) with `#047857` text.
- **Urgent Announcement**: Soft red tint (`#FEF2F2`) with `#B91C1C` text.

### Input Fields
- Minimum height 48px for thumb touch readiness.
- Background `#FFFFFF`, border `1px solid #CBD5E1`, border-radius 8px (`rounded-lg`).
- Focus state brings a sharp 2px ring in Royal Blue (`#2563EB`) with zero displacement.

### Checkboxes & Radios
- Rounded checkbox corners (4px) and full-round radio rings (16px diameter).
- Checked states trigger `#2563EB` fill with a high-contrast white glyph.

### Lists & Navigation
- Borderless grouped list cards with `1px solid #F1F5F9` dividers.
- Thumb-friendly bottom app bar on mobile featuring 4 primary destinations: Home, MPP News, Welfare Desk, and Student Profile.