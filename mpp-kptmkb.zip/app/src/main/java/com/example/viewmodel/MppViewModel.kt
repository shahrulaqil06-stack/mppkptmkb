package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.SampleData
import com.example.model.Announcement
import com.example.model.AppNotification
import com.example.model.BadgeType
import com.example.model.CampusEvent
import com.example.model.Complaint
import com.example.model.ComplaintStatus
import com.example.model.CounselingBooking
import com.example.model.ExcoMember
import com.example.model.PaperworkTemplate
import com.example.model.RentalHouse
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.random.Random

data class MppUiState(
    val currentTab: Int = 0, // 0: Utama, 1: Servis, 2: Aduan, 3: Takwim, 4: Profil/Admin
    val isDarkMode: Boolean = false,
    val searchQuery: String = "",
    val isAdminMode: Boolean = false,
    val announcements: List<Announcement> = SampleData.initialAnnouncements,
    val complaints: List<Complaint> = SampleData.initialComplaints,
    val events: List<CampusEvent> = SampleData.initialEvents,
    val excos: List<ExcoMember> = SampleData.initialExcos,
    val rentalHouses: List<RentalHouse> = SampleData.initialRentalHouses,
    val templates: List<PaperworkTemplate> = SampleData.initialTemplates,
    val notifications: List<AppNotification> = SampleData.initialNotifications,
    val counselingBookings: List<CounselingBooking> = emptyList(),
    // Active Modals & Dialogs
    val activeComplaintDetail: Complaint? = null,
    val activeEventDetail: CampusEvent? = null,
    val activeExcoDetail: ExcoMember? = null,
    val activeTemplateDetail: PaperworkTemplate? = null,
    val activeRentalDetail: RentalHouse? = null,
    val isMcGeneratorOpen: Boolean = false,
    val isCounselingBookingOpen: Boolean = false,
    val isDermasiswaOpen: Boolean = false,
    val isExamScheduleOpen: Boolean = false,
    val isNotificationsOpen: Boolean = false,
    val toastMessage: String? = null,
    val generatedLetterContent: String? = null
)

class MppViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(MppUiState())
    val uiState: StateFlow<MppUiState> = _uiState.asStateFlow()

    fun setTab(index: Int) {
        _uiState.update { it.copy(currentTab = index) }
    }

    fun toggleDarkMode() {
        _uiState.update { it.copy(isDarkMode = !it.isDarkMode) }
    }

    fun toggleAdminMode() {
        _uiState.update { 
            val newAdminState = !it.isAdminMode
            it.copy(
                isAdminMode = newAdminState,
                toastMessage = if (newAdminState) "Mod Admin Exco Diaktifkan" else "Mod Pelajar Biasa Diaktifkan"
            )
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    // Modal Triggers
    fun openComplaintDetail(complaint: Complaint) {
        _uiState.update { it.copy(activeComplaintDetail = complaint) }
    }
    fun closeComplaintDetail() {
        _uiState.update { it.copy(activeComplaintDetail = null) }
    }

    fun openEventDetail(event: CampusEvent) {
        _uiState.update { it.copy(activeEventDetail = event) }
    }
    fun closeEventDetail() {
        _uiState.update { it.copy(activeEventDetail = null) }
    }

    fun openExcoDetail(exco: ExcoMember) {
        _uiState.update { it.copy(activeExcoDetail = exco) }
    }
    fun closeExcoDetail() {
        _uiState.update { it.copy(activeExcoDetail = null) }
    }

    fun openTemplateDetail(template: PaperworkTemplate) {
        _uiState.update { it.copy(activeTemplateDetail = template) }
    }
    fun closeTemplateDetail() {
        _uiState.update { it.copy(activeTemplateDetail = null) }
    }

    fun openRentalDetail(house: RentalHouse) {
        _uiState.update { it.copy(activeRentalDetail = house) }
    }
    fun closeRentalDetail() {
        _uiState.update { it.copy(activeRentalDetail = null) }
    }

    fun setMcGeneratorOpen(open: Boolean) {
        _uiState.update { it.copy(isMcGeneratorOpen = open) }
    }

    fun setCounselingBookingOpen(open: Boolean) {
        _uiState.update { it.copy(isCounselingBookingOpen = open) }
    }

    fun setDermasiswaOpen(open: Boolean) {
        _uiState.update { it.copy(isDermasiswaOpen = open) }
    }

    fun setExamScheduleOpen(open: Boolean) {
        _uiState.update { it.copy(isExamScheduleOpen = open) }
    }

    fun setNotificationsOpen(open: Boolean) {
        _uiState.update { it.copy(isNotificationsOpen = open) }
    }

    fun markAllNotificationsRead() {
        _uiState.update { state ->
            state.copy(notifications = state.notifications.map { it.copy(isRead = true) })
        }
    }

    // Student Operations
    fun submitComplaint(
        category: String,
        details: String,
        isAnonymous: Boolean,
        imageUri: String? = null,
        studentName: String = "Pelajar KPTMKB",
        matricId: String = "KB2401-8899"
    ): String {
        val randomNum = Random.nextInt(1000, 9999)
        val newId = "#ADU-$randomNum"
        val newComplaint = Complaint(
            id = newId,
            title = if (details.length > 28) details.take(25) + "..." else details,
            category = category,
            dateSubmitted = "Hari ini",
            status = ComplaintStatus.PENDING,
            description = details,
            isAnonymous = isAnonymous,
            studentName = if (isAnonymous) "Rahsia" else studentName,
            matricId = if (isAnonymous) "Rahsia" else matricId,
            imageUri = imageUri,
            excoResponse = "Aduan telah didaftarkan dalam sistem dan diserahkan kepada Exco $category.",
            updatedAt = "Baru sahaja"
        )

        val newNotif = AppNotification(
            id = "notif-${System.currentTimeMillis()}",
            title = "Aduan Baru $newId",
            message = "Aduan anda bagi kategori $category telah selamat diterima oleh MPP.",
            timeAgo = "Baru sahaja",
            type = "INFO"
        )

        _uiState.update { state ->
            state.copy(
                complaints = listOf(newComplaint) + state.complaints,
                notifications = listOf(newNotif) + state.notifications,
                toastMessage = "Aduan berjaya dihantar! Rujukan: $newId"
            )
        }
        return newId
    }

    fun registerEvent(eventId: String, participantName: String, matricNo: String): Boolean {
        var success = false
        _uiState.update { state ->
            val updatedEvents = state.events.map { event ->
                if (event.id == eventId && event.availableSlots > 0) {
                    success = true
                    event.copy(
                        availableSlots = event.availableSlots - 1,
                        registeredParticipants = event.registeredParticipants + "$participantName ($matricNo)"
                    )
                } else {
                    event
                }
            }
            state.copy(
                events = updatedEvents,
                toastMessage = if (success) "Pendaftaran berjaya disahkan!" else "Maaf, slot telah penuh!"
            )
        }
        return success
    }

    fun bookCounseling(
        counselor: String,
        date: String,
        time: String,
        category: String,
        notes: String
    ) {
        val newBooking = CounselingBooking(
            id = "CSL-${Random.nextInt(100, 999)}",
            studentName = "Ahmad Faiz",
            matricNo = "KB2309-4412",
            counselorName = counselor,
            bookingDate = date,
            timeSlot = time,
            category = category,
            notes = notes
        )
        _uiState.update { state ->
            state.copy(
                counselingBookings = listOf(newBooking) + state.counselingBookings,
                isCounselingBookingOpen = false,
                toastMessage = "Temujanji kaunseling bersama $counselor telah disahkan (Slot: $time, $date)"
            )
        }
    }

    fun generateMcLetter(
        name: String,
        matric: String,
        program: String,
        dates: String,
        reason: String,
        lecturer: String,
        subjectCode: String
    ) {
        val letter = """
            KOLEJ POLY-TECH MARA KOTA BHARU
            BAHAGIAN HAL EHWAL AKADEMIK (BHEA)
            Rujukan Dokumen: BHEA.TT.08.PdP.02
            --------------------------------------------------------
            SURAT PEMBERITAHUAN KETIDAKHADIRAN KULIAH / PEPERIKSAAN

            Kepada:
            $lecturer
            Pensyarah Kursus $subjectCode
            Kolej Poly-Tech MARA Kota Bharu

            Tarikh: 23 Februari 2026

            Tuan/Puan,
            PER: PEMBERITAHUAN KETIDAKHADIRAN KULIAH KERANA $reason

            Dengan segala hormatnya dimaklumkan bahawa penama di bawah tidak dapat hadir ke sesi kuliah:

            Nama Pelajar : $name
            No. Matrik   : $matric
            Program      : $program
            Kursus/Kod   : $subjectCode
            Tarikh Cuti  : $dates
            Sebab / MC   : $reason

            2. Bersama-sama surat ini dilampirkan salinan Sijil Sakit (MC) / Dokumen Sokongan yang berkaitan untuk tindakan dan rekod kehadiran pihak tuan/puan.

            Sekian, terima kasih.

            "MESRA • PRIHATIN • PEKA"

            Yang benar,
            $name
            Pelajar KPTM Kota Bharu
        """.trimIndent()

        _uiState.update { it.copy(generatedLetterContent = letter, toastMessage = "Surat MC/Cuti rasmi berjaya dijana!") }
    }

    fun clearGeneratedLetter() {
        _uiState.update { it.copy(generatedLetterContent = null) }
    }

    // Admin Operations
    fun updateComplaintStatus(complaintId: String, newStatus: ComplaintStatus, responseNote: String) {
        _uiState.update { state ->
            val updated = state.complaints.map { comp ->
                if (comp.id == complaintId) {
                    comp.copy(
                        status = newStatus,
                        excoResponse = responseNote.ifBlank { comp.excoResponse },
                        updatedAt = "Baru sahaja dikemaskini"
                    )
                } else {
                    comp
                }
            }
            state.copy(
                complaints = updated,
                toastMessage = "Status aduan $complaintId ditukar ke: ${newStatus.label}"
            )
        }
    }

    fun deleteComplaint(complaintId: String) {
        _uiState.update { state ->
            state.copy(
                complaints = state.complaints.filter { it.id != complaintId },
                toastMessage = "Aduan $complaintId telah dipadam"
            )
        }
    }

    fun addAnnouncement(
        title: String,
        description: String,
        category: String,
        badgeType: BadgeType,
        timeOrDate: String,
        actionText: String,
        merit: Int,
        imageUri: String? = null,
        details: String = ""
    ) {
        val newAnn = Announcement(
            id = "ann-${System.currentTimeMillis()}",
            title = title,
            description = description,
            category = category,
            badgeLabel = category,
            badgeType = badgeType,
            timeOrDateInfo = timeOrDate,
            actionText = actionText.ifBlank { "Lihat Butiran" },
            meritPoints = merit,
            imageUri = imageUri,
            detailsUrlOrNotes = details
        )
        _uiState.update { state ->
            state.copy(
                announcements = listOf(newAnn) + state.announcements,
                toastMessage = "Hebahan baru berjaya diterbitkan!"
            )
        }
    }

    fun deleteAnnouncement(id: String) {
        _uiState.update { state ->
            state.copy(
                announcements = state.announcements.filter { it.id != id },
                toastMessage = "Hebahan telah dipadam"
            )
        }
    }

    fun addEvent(
        title: String,
        category: String,
        month: String,
        day: String,
        dateRange: String,
        location: String,
        targetAudience: String,
        buttonText: String,
        isVolunteer: Boolean,
        totalSlots: Int,
        merit: Int,
        imageUri: String? = null,
        description: String = ""
    ) {
        val newEvent = CampusEvent(
            id = "evt-${System.currentTimeMillis()}",
            title = title,
            category = category,
            monthShort = month.uppercase(),
            dayNumber = day,
            dateRange = dateRange,
            location = location,
            targetAudience = targetAudience,
            buttonText = buttonText.ifBlank { if (isVolunteer) "Daftar Sukarelawan" else "Daftar Peserta" },
            isVolunteer = isVolunteer,
            availableSlots = totalSlots,
            totalSlots = totalSlots,
            meritPoints = merit,
            imageUri = imageUri,
            description = description
        )
        _uiState.update { state ->
            state.copy(
                events = state.events + newEvent,
                toastMessage = "Program $title berjaya ditambah ke Takwim!"
            )
        }
    }

    fun deleteEvent(id: String) {
        _uiState.update { state ->
            state.copy(
                events = state.events.filter { it.id != id },
                toastMessage = "Program telah dipadam"
            )
        }
    }

    fun addRentalHouse(
        title: String,
        location: String,
        rent: String,
        gender: String,
        distance: String,
        amenities: List<String>,
        phone: String,
        imageUri: String? = null,
        description: String = ""
    ) {
        val newHouse = RentalHouse(
            id = "house-${System.currentTimeMillis()}",
            title = title,
            location = location,
            monthlyRent = rent,
            genderPreference = gender,
            distanceToCampus = distance,
            amenities = amenities,
            contactPhone = phone,
            imageUri = imageUri,
            description = description
        )
        _uiState.update { state ->
            state.copy(
                rentalHouses = listOf(newHouse) + state.rentalHouses,
                toastMessage = "Rumah sewa baru berjaya disenaraikan!"
            )
        }
    }

    fun deleteRentalHouse(id: String) {
        _uiState.update { state ->
            state.copy(
                rentalHouses = state.rentalHouses.filter { it.id != id },
                toastMessage = "Rumah sewa telah dipadam"
            )
        }
    }
}
