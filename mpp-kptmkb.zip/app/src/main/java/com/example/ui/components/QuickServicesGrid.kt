package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DownloadForOffline
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun QuickServicesGrid(
    onMcGeneratorClick: () -> Unit,
    onCounselingClick: () -> Unit,
    onRentalClick: () -> Unit,
    onAduanClick: () -> Unit,
    onPaperworkClick: () -> Unit,
    onTakwimClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Servis Digital Pelajar",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Kemudahan harian pantas berpusat MPP",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHighest
            ) {
                Text(
                    text = "6 Modul",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }

        // 2-Column Grid (Row 1)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ServiceTile(
                title = "Penjana Surat MC / Cuti",
                badge = "Auto-PDF",
                subtitle = "BHEA.TT.08.PdP.02",
                icon = Icons.Default.Description,
                iconBg = MaterialTheme.colorScheme.secondaryContainer,
                iconTint = MaterialTheme.colorScheme.secondary,
                badgeBg = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                badgeFg = MaterialTheme.colorScheme.secondary,
                onClick = onMcGeneratorClick,
                testTag = "service_mc_tile",
                modifier = Modifier.weight(1f)
            )

            ServiceTile(
                title = "Tempahan Kaunseling",
                badge = "Sulit",
                subtitle = "Let's Talk! Kaunselor",
                icon = Icons.Default.Favorite,
                iconBg = MaterialTheme.colorScheme.errorContainer,
                iconTint = MaterialTheme.colorScheme.onErrorContainer,
                badgeBg = MaterialTheme.colorScheme.errorContainer,
                badgeFg = MaterialTheme.colorScheme.onErrorContainer,
                onClick = onCounselingClick,
                testTag = "service_counseling_tile",
                modifier = Modifier.weight(1f)
            )
        }

        // Row 2
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ServiceTile(
                title = "Direktori Rumah Sewa",
                badge = "42+ Rumah",
                subtitle = "Sekitar Kota Bharu",
                icon = Icons.Default.Apartment,
                iconBg = MaterialTheme.colorScheme.tertiaryContainer,
                iconTint = MaterialTheme.colorScheme.onTertiaryContainer,
                badgeBg = MaterialTheme.colorScheme.tertiaryContainer,
                badgeFg = MaterialTheme.colorScheme.onTertiaryContainer,
                onClick = onRentalClick,
                testTag = "service_rental_tile",
                modifier = Modifier.weight(1f)
            )

            ServiceTile(
                title = "E-Aduan Pelajar",
                badge = "Respon 24j",
                subtitle = "Fasiliti & Kebajikan",
                icon = Icons.Default.RateReview,
                iconBg = MaterialTheme.colorScheme.surfaceContainerHigh,
                iconTint = MaterialTheme.colorScheme.secondary,
                badgeBg = MaterialTheme.colorScheme.surfaceContainer,
                badgeFg = MaterialTheme.colorScheme.onSurface,
                onClick = onAduanClick,
                testTag = "service_aduan_tile",
                modifier = Modifier.weight(1f)
            )
        }

        // Row 3
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ServiceTile(
                title = "Pusat Dokumen Kertas Kerja",
                badge = "HEP / BHEA",
                subtitle = "Templat PDF & Word",
                icon = Icons.Default.DownloadForOffline,
                iconBg = MaterialTheme.colorScheme.surfaceContainerHigh,
                iconTint = MaterialTheme.colorScheme.onSurface,
                badgeBg = MaterialTheme.colorScheme.surfaceContainer,
                badgeFg = MaterialTheme.colorScheme.onSurfaceVariant,
                onClick = onPaperworkClick,
                testTag = "service_paperwork_tile",
                modifier = Modifier.weight(1f)
            )

            ServiceTile(
                title = "Takwim & Merit Program",
                badge = "Sem 2 25/26",
                subtitle = "Jadual Bulanan Kampus",
                icon = Icons.Default.EventAvailable,
                iconBg = MaterialTheme.colorScheme.secondaryContainer,
                iconTint = MaterialTheme.colorScheme.secondary,
                badgeBg = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                badgeFg = MaterialTheme.colorScheme.secondary,
                onClick = onTakwimClick,
                testTag = "service_takwim_tile",
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun ServiceTile(
    title: String,
    badge: String,
    subtitle: String,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    badgeBg: Color,
    badgeFg: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .height(150.dp)
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(iconBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = iconTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = badgeBg
                    ) {
                        Text(
                            text = badge,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = badgeFg,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.5.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 18.sp,
                    maxLines = 2
                )
            }

            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}
