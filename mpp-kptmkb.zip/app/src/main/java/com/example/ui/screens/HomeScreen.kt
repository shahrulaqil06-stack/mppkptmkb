package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Announcement
import com.example.model.CampusEvent
import com.example.model.Complaint
import com.example.model.ExcoMember
import com.example.ui.components.AduanSection
import com.example.ui.components.EmergencyHotlineFooter
import com.example.ui.components.EventsSection
import com.example.ui.components.ExcoSection
import com.example.ui.components.HeroCarousel
import com.example.ui.components.QuickServicesGrid
import com.example.viewmodel.MppUiState

@Composable
fun HomeScreen(
    uiState: MppUiState,
    onAnnouncementClick: (Announcement) -> Unit,
    onLamegaClick: () -> Unit,
    onExamScheduleClick: () -> Unit,
    onDermasiswaClick: () -> Unit,
    onMcGeneratorClick: () -> Unit,
    onCounselingClick: () -> Unit,
    onRentalClick: () -> Unit,
    onAduanClick: () -> Unit,
    onPaperworkClick: () -> Unit,
    onTakwimClick: () -> Unit,
    onSubmitComplaint: (category: String, details: String, isAnonymous: Boolean, imageUri: String?) -> Unit,
    onComplaintClick: (Complaint) -> Unit,
    onViewAllAduanClick: () -> Unit,
    onEventClick: (CampusEvent) -> Unit,
    onViewAllEventsClick: () -> Unit,
    onExcoClick: (ExcoMember) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val query = uiState.searchQuery.trim().lowercase()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("home_screen_content"),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        // If searching, show filtered quick search results banner
        if (query.isNotEmpty()) {
            SearchResultsBanner(
                query = query,
                uiState = uiState,
                onAnnouncementClick = onAnnouncementClick,
                onEventClick = onEventClick,
                onExcoClick = onExcoClick,
                onMcGeneratorClick = onMcGeneratorClick,
                onCounselingClick = onCounselingClick,
                onRentalClick = onRentalClick
            )
        }

        // 1. Hero & Highlight Announcement Carousel
        HeroCarousel(
            announcements = if (query.isEmpty()) uiState.announcements else uiState.announcements.filter {
                it.title.lowercase().contains(query) || it.description.lowercase().contains(query) || it.category.lowercase().contains(query)
            },
            onAnnouncementClick = onAnnouncementClick,
            onLamegaClick = onLamegaClick,
            onExamScheduleClick = onExamScheduleClick,
            onDermasiswaClick = onDermasiswaClick
        )

        // 2. Quick Access Services Grid
        QuickServicesGrid(
            onMcGeneratorClick = onMcGeneratorClick,
            onCounselingClick = onCounselingClick,
            onRentalClick = onRentalClick,
            onAduanClick = onAduanClick,
            onPaperworkClick = onPaperworkClick,
            onTakwimClick = onTakwimClick
        )

        // 3. Interactive E-Aduan & Tracker Module
        AduanSection(
            complaints = if (query.isEmpty()) uiState.complaints else uiState.complaints.filter {
                it.title.lowercase().contains(query) || it.description.lowercase().contains(query) || it.category.lowercase().contains(query) || it.id.lowercase().contains(query)
            },
            onSubmitComplaint = onSubmitComplaint,
            onComplaintClick = onComplaintClick,
            onViewAllClick = onViewAllAduanClick
        )

        // 4. Student Event Calendar & Volunteer Sign-Up
        EventsSection(
            events = if (query.isEmpty()) uiState.events else uiState.events.filter {
                it.title.lowercase().contains(query) || it.location.lowercase().contains(query) || it.category.lowercase().contains(query)
            },
            onEventClick = onEventClick,
            onViewAllClick = onViewAllEventsClick
        )

        // 5. MPP Executive Directory
        ExcoSection(
            excos = if (query.isEmpty()) uiState.excos else uiState.excos.filter {
                it.name.lowercase().contains(query) || it.roleTitle.lowercase().contains(query) || it.portfolio.lowercase().contains(query)
            },
            onExcoClick = onExcoClick
        )

        // 6. Emergency Hotlines & Footer
        EmergencyHotlineFooter()

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun SearchResultsBanner(
    query: String,
    uiState: MppUiState,
    onAnnouncementClick: (Announcement) -> Unit,
    onEventClick: (CampusEvent) -> Unit,
    onExcoClick: (ExcoMember) -> Unit,
    onMcGeneratorClick: () -> Unit,
    onCounselingClick: () -> Unit,
    onRentalClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                Text(
                    text = "Hasil Carian: \"$query\"",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Quick service triggers if match
            if ("mc".contains(query) || "cuti".contains(query) || "surat".contains(query)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLowest,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onMcGeneratorClick() }
                ) {
                    Text(
                        text = "→ Buka Modul: Penjana Surat MC / Cuti (BHEA.TT.08.PdP.02)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
            if ("kaunselor".contains(query) || "kaunseling".contains(query) || "mental".contains(query)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLowest,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onCounselingClick() }
                ) {
                    Text(
                        text = "→ Buka Modul: Tempahan Sesi Kaunseling Sulit",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
            if ("sewa".contains(query) || "rumah".contains(query) || "bilik".contains(query)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLowest,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onRentalClick() }
                ) {
                    Text(
                        text = "→ Buka Modul: Direktori Rumah Sewa Pelajar KPTMKB",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}
