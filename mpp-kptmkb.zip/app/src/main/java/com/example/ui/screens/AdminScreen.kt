package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Announcement
import com.example.model.BadgeType
import com.example.model.CampusEvent
import com.example.model.Complaint
import com.example.model.ComplaintStatus
import com.example.model.RentalHouse
import com.example.viewmodel.MppUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    uiState: MppUiState,
    onToggleAdminMode: () -> Unit,
    onUpdateComplaintStatus: (id: String, status: ComplaintStatus, responseNote: String) -> Unit,
    onDeleteComplaint: (id: String) -> Unit,
    onAddAnnouncement: (title: String, desc: String, category: String, badgeType: BadgeType, time: String, actionText: String, merit: Int, imageUri: String?, details: String) -> Unit,
    onDeleteAnnouncement: (id: String) -> Unit,
    onAddEvent: (title: String, category: String, month: String, day: String, dateRange: String, location: String, audience: String, btnText: String, isVolunteer: Boolean, slots: Int, merit: Int, imageUri: String?, desc: String) -> Unit,
    onDeleteEvent: (id: String) -> Unit,
    onAddRentalHouse: (title: String, location: String, rent: String, gender: String, dist: String, amenities: List<String>, phone: String, imageUri: String?, desc: String) -> Unit,
    onDeleteRentalHouse: (id: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var selectedSection by remember { mutableIntStateOf(0) } // 0: Aduan, 1: Hebahan, 2: Takwim, 3: Rumah Sewa

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Admin Mode Status & Toggle Header Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (uiState.isAdminMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLowest
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (uiState.isAdminMode) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = if (uiState.isAdminMode) Color.White else MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = if (uiState.isAdminMode) "Panel Pentadbiran Exco MPP" else "Profil Mahasiswa KPTMKB",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.isAdminMode) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (uiState.isAdminMode) "Akses Penuh Pengurusan & Muat Naik Gambar" else "Aktifkan Mod Admin untuk kawalan sistem",
                            fontSize = 11.5.sp,
                            color = if (uiState.isAdminMode) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.outline
                        )
                    }
                }

                Switch(
                    checked = uiState.isAdminMode,
                    onCheckedChange = { onToggleAdminMode() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = MaterialTheme.colorScheme.secondary
                    ),
                    modifier = Modifier.testTag("admin_mode_switch")
                )
            }
        }

        if (!uiState.isAdminMode) {
            // Student Profile Mode View
            StudentProfileView(onSwitchToAdmin = onToggleAdminMode)
        } else {
            // Full Admin Management Suite
            // Sub-Navigation Pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "Urus Aduan (${uiState.complaints.size})",
                    "Hebahan & Gambar (${uiState.announcements.size})",
                    "Program & Takwim (${uiState.events.size})",
                    "Rumah Sewa (${uiState.rentalHouses.size})"
                ).forEachIndexed { index, label ->
                    val isSelected = selectedSection == index
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier = Modifier.clickable { selectedSection = index }
                    ) {
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            // Sub-Section Content
            when (selectedSection) {
                0 -> AdminAduanSection(
                    complaints = uiState.complaints,
                    onUpdateStatus = onUpdateComplaintStatus,
                    onDeleteComplaint = onDeleteComplaint
                )
                1 -> AdminHebahanSection(
                    announcements = uiState.announcements,
                    onAddAnnouncement = onAddAnnouncement,
                    onDeleteAnnouncement = onDeleteAnnouncement
                )
                2 -> AdminEventsSection(
                    events = uiState.events,
                    onAddEvent = onAddEvent,
                    onDeleteEvent = onDeleteEvent
                )
                3 -> AdminRentalSection(
                    houses = uiState.rentalHouses,
                    onAddHouse = onAddRentalHouse,
                    onDeleteHouse = onDeleteRentalHouse
                )
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun StudentProfileView(
    onSwitchToAdmin: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                AsyncImage(
                    model = "https://lh3.googleusercontent.com/aida/ALJJyrAhX2M50HLPuU_NmYzyte_RZD6Sdd-8ipr-sEK7F5J0ip_YcGKlAwE2Q8MEOsXO8fUO4Rkp8VpUxTpex5LjqGZvSD3j3FMqhKwQob5kbJr6NvTM2od1V6zAXVl03adifBHgvysSkys77H3ovT65CITwOW8Uu3jtvHi95KDCsH_31fV2efQuEZouvJdoKxy26zd6vsmUF8ZLLgd6mZmUKc8ipqjKXpCRTLTIWB2UBsO8bv9oTbs9shfE1T4I",
                    contentDescription = "Foto Profil",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                )

                Column {
                    Text(text = "Wan Muhammad Aqil", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(text = "No. Matrik: KB2309-8812", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, fontFamily = FontFamily.Monospace)
                    Text(text = "Diploma Sains Komputer (Semester 4)", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.outline)
                }
            }

            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceContainerLow) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = "Status Pendaftaran: Aktif", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "Merit Terkumpul: 140 / 200 Merit", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Text(text = "Kolej Kediaman: Rumah Sewa Luar (Pengkalan Chepa)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Button(
                onClick = onSwitchToAdmin,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Buka Mod Admin Exco MPP")
            }
        }
    }
}

// ---------------- SUB-SECTION 1: ADMIN ADUAN ----------------
@Composable
fun AdminAduanSection(
    complaints: List<Complaint>,
    onUpdateStatus: (id: String, status: ComplaintStatus, responseNote: String) -> Unit,
    onDeleteComplaint: (id: String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = "Pengurusan & Tindakan E-Aduan", fontSize = 16.sp, fontWeight = FontWeight.Bold)

        complaints.forEach { complaint ->
            AdminComplaintItemCard(
                complaint = complaint,
                onUpdateStatus = { newStatus, note -> onUpdateStatus(complaint.id, newStatus, note) },
                onDelete = { onDeleteComplaint(complaint.id) }
            )
        }
    }
}

@Composable
fun AdminComplaintItemCard(
    complaint: Complaint,
    onUpdateStatus: (ComplaintStatus, String) -> Unit,
    onDelete: () -> Unit
) {
    var responseNote by remember { mutableStateOf(complaint.excoResponse ?: "") }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = complaint.id, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                        Text(text = complaint.category, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Padam", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                }
            }

            Text(text = complaint.description, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)

            complaint.imageUri?.let { uri ->
                AsyncImage(
                    model = uri,
                    contentDescription = "Lampiran Aduan",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
            }

            // Status Changer Buttons
            Text(text = "Tukar Status:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ComplaintStatus.entries.forEach { status ->
                    val isSelected = complaint.status == status
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onUpdateStatus(status, responseNote) }
                    ) {
                        Text(
                            text = status.label,
                            fontSize = 9.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }

            // Exco Note Field
            OutlinedTextField(
                value = responseNote,
                onValueChange = { responseNote = it },
                label = { Text("Nota Tindakan / Maklum Balas Exco") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { onUpdateStatus(complaint.status, responseNote) },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Simpan Maklum Balas Exco", fontSize = 12.sp)
            }
        }
    }
}

// ---------------- SUB-SECTION 2: ADMIN HEBAHAN WITH PICTURE UPLOAD ----------------
@Composable
fun AdminHebahanSection(
    announcements: List<Announcement>,
    onAddAnnouncement: (title: String, desc: String, category: String, badgeType: BadgeType, time: String, actionText: String, merit: Int, imageUri: String?, details: String) -> Unit,
    onDeleteAnnouncement: (id: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("PENTING") }
    var timeOrDate by remember { mutableStateOf("Segera") }
    var actionText by remember { mutableStateOf("Daftar Sekarang") }
    var meritPoints by remember { mutableStateOf("60") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var showForm by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Pengurusan Hebahan & Gambar", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = { showForm = !showForm },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                modifier = Modifier.testTag("tambah_hebahan_btn")
            ) {
                Icon(imageVector = if (showForm) Icons.Default.Close else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = if (showForm) "Tutup" else "Tambah Hebahan", fontSize = 12.sp)
            }
        }

        // Add Announcement Form (with Photo Upload!)
        if (showForm) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = "Tambah Hebahan Baru (Bersama Gambar Poster)", fontSize = 14.sp, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Tajuk Hebahan") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Keterangan Hebahan") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = { Text("Kategori (cth: PENTING)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = meritPoints,
                            onValueChange = { meritPoints = it },
                            label = { Text("Merit HEP") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = timeOrDate,
                        onValueChange = { timeOrDate = it },
                        label = { Text("Tarikh / Tempoh Masa (cth: 5 Hari Lagi)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Photo Picker Button & Preview
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "Gambar / Poster Hebahan:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (selectedImageUri == null) "Pilih Gambar Poster Dari Galeri" else "Tukar Gambar Dipilih")
                        }

                        selectedImageUri?.let { uri ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            ) {
                                AsyncImage(
                                    model = uri,
                                    contentDescription = "Poster",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.matchParentSize()
                                )
                                IconButton(
                                    onClick = { selectedImageUri = null },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .size(28.dp)
                                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onAddAnnouncement(
                                    title,
                                    description,
                                    category.uppercase(),
                                    if (category.equals("PENTING", true)) BadgeType.ERROR else BadgeType.SECONDARY,
                                    timeOrDate,
                                    actionText,
                                    meritPoints.toIntOrNull() ?: 0,
                                    selectedImageUri?.toString(),
                                    ""
                                )
                                title = ""
                                description = ""
                                selectedImageUri = null
                                showForm = false
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Terbitkan Hebahan Sekarang")
                    }
                }
            }
        }

        // Existing Announcements List
        announcements.forEach { ann ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = ann.title, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                        Text(text = "${ann.category} • ${ann.timeOrDateInfo}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                    IconButton(onClick = { onDeleteAnnouncement(ann.id) }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Padam", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

// ---------------- SUB-SECTION 3: ADMIN EVENTS WITH PICTURE UPLOAD ----------------
@Composable
fun AdminEventsSection(
    events: List<CampusEvent>,
    onAddEvent: (title: String, category: String, month: String, day: String, dateRange: String, location: String, audience: String, btnText: String, isVolunteer: Boolean, slots: Int, merit: Int, imageUri: String?, desc: String) -> Unit,
    onDeleteEvent: (id: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Inovasi Kampus") }
    var month by remember { mutableStateOf("MAC") }
    var day by remember { mutableStateOf("25") }
    var dateRange by remember { mutableStateOf("25 - 27 Mac 2026") }
    var location by remember { mutableStateOf("Dewan Bunga Raya") }
    var targetAudience by remember { mutableStateOf("Semua Pelajar") }
    var slots by remember { mutableStateOf("50") }
    var merit by remember { mutableStateOf("80") }
    var isVolunteer by remember { mutableStateOf(false) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var showForm by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Pengurusan Program & Takwim", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = { showForm = !showForm },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(imageVector = if (showForm) Icons.Default.Close else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = if (showForm) "Tutup" else "Tambah Program", fontSize = 12.sp)
            }
        }

        if (showForm) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = "Tambah Program / Sukarelawan Baru", fontSize = 14.sp, fontWeight = FontWeight.Bold)

                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Nama Program") }, modifier = Modifier.fillMaxWidth())

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = month, onValueChange = { month = it }, label = { Text("Bulan (cth: MAC)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = day, onValueChange = { day = it }, label = { Text("Hari (cth: 25)") }, modifier = Modifier.weight(1f))
                    }

                    OutlinedTextField(value = dateRange, onValueChange = { dateRange = it }, label = { Text("Tarikh Penuh (cth: 25 - 27 Mac 2026)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Lokasi Program") }, modifier = Modifier.fillMaxWidth())

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = slots, onValueChange = { slots = it }, label = { Text("Kouta Slot") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = merit, onValueChange = { merit = it }, label = { Text("Merit HEP") }, modifier = Modifier.weight(1f))
                    }

                    // Photo Picker Button
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "Banner / Poster Program:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (selectedImageUri == null) "Pilih Poster Program Dari Galeri" else "Tukar Poster Dipilih")
                        }

                        selectedImageUri?.let { uri ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            ) {
                                AsyncImage(model = uri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
                                IconButton(
                                    onClick = { selectedImageUri = null },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .size(28.dp)
                                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onAddEvent(
                                    title, category, month, day, dateRange, location, targetAudience,
                                    if (isVolunteer) "Daftar Sukarelawan" else "Daftar Peserta",
                                    isVolunteer, slots.toIntOrNull() ?: 40, merit.toIntOrNull() ?: 60,
                                    selectedImageUri?.toString(), ""
                                )
                                title = ""
                                selectedImageUri = null
                                showForm = false
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Terbitkan Program ke Takwim")
                    }
                }
            }
        }

        // Events list
        events.forEach { evt ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = evt.title, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                        Text(text = "${evt.dateRange} • ${evt.location}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        if (evt.registeredParticipants.isNotEmpty()) {
                            Text(text = "Peserta Didaftar: ${evt.registeredParticipants.size} orang", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                    IconButton(onClick = { onDeleteEvent(evt.id) }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Padam", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

// ---------------- SUB-SECTION 4: ADMIN RUMAH SEWA WITH PICTURE UPLOAD ----------------
@Composable
fun AdminRentalSection(
    houses: List<RentalHouse>,
    onAddHouse: (title: String, location: String, rent: String, gender: String, dist: String, amenities: List<String>, phone: String, imageUri: String?, desc: String) -> Unit,
    onDeleteHouse: (id: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var monthlyRent by remember { mutableStateOf("RM 180 / orang") }
    var gender by remember { mutableStateOf("Lelaki") }
    var distance by remember { mutableStateOf("5 minit dari KPTMKB") }
    var phone by remember { mutableStateOf("019-9123456") }
    var description by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var showForm by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        selectedImageUri = uri
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Pengurusan Rumah Sewa & Gambar", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = { showForm = !showForm },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(imageVector = if (showForm) Icons.Default.Close else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = if (showForm) "Tutup" else "Tambah Rumah", fontSize = 12.sp)
            }
        }

        if (showForm) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = "Senaraikan Rumah Sewa Baru", fontSize = 14.sp, fontWeight = FontWeight.Bold)

                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Nama Kediaman / Rumah Sewa") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Kawasan / Alamat Ringkas") }, modifier = Modifier.fillMaxWidth())

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = monthlyRent, onValueChange = { monthlyRent = it }, label = { Text("Kadar Sewa (cth: RM 180)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = gender, onValueChange = { gender = it }, label = { Text("Jantina (Lelaki/Perempuan)") }, modifier = Modifier.weight(1f))
                    }

                    OutlinedTextField(value = distance, onValueChange = { distance = it }, label = { Text("Jarak ke Kampus") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("No. Telefon Tuan Rumah") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Keterangan Kemudahan (WiFi, Aircond, dll)") }, minLines = 2, modifier = Modifier.fillMaxWidth())

                    // Photo Picker
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "Gambar Rumah Sewa:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        OutlinedButton(
                            onClick = { photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (selectedImageUri == null) "Pilih Gambar Rumah Sewa Dari Galeri" else "Tukar Gambar Dipilih")
                        }

                        selectedImageUri?.let { uri ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            ) {
                                AsyncImage(model = uri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
                                IconButton(
                                    onClick = { selectedImageUri = null },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(4.dp)
                                        .size(28.dp)
                                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onAddHouse(
                                    title, location, monthlyRent, gender, distance,
                                    listOf("WiFi", "Peti Ais", "Mesin Basuh"),
                                    phone, selectedImageUri?.toString(), description
                                )
                                title = ""
                                selectedImageUri = null
                                showForm = false
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Terbitkan Iklan Rumah Sewa")
                    }
                }
            }
        }

        // Houses list
        houses.forEach { h ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(text = h.title, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
                        Text(text = "${h.monthlyRent} • ${h.genderPreference} • ${h.location}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                    IconButton(onClick = { onDeleteHouse(h.id) }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Padam", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}
