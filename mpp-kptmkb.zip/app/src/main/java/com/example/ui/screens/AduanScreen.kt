package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Complaint
import com.example.model.ComplaintStatus
import com.example.ui.components.AduanSection
import com.example.ui.components.ComplaintTrackerCard
import com.example.viewmodel.MppUiState

@Composable
fun AduanScreen(
    uiState: MppUiState,
    onSubmitComplaint: (category: String, details: String, isAnonymous: Boolean, imageUri: String?) -> Unit,
    onComplaintClick: (Complaint) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var selectedStatusFilter by remember { mutableStateOf("Semua") }

    val pendingCount = uiState.complaints.count { it.status == ComplaintStatus.PENDING }
    val inProgressCount = uiState.complaints.count { it.status == ComplaintStatus.IN_PROGRESS }
    val resolvedCount = uiState.complaints.count { it.status == ComplaintStatus.RESOLVED }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Page Title
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "Saluran E-Aduan Mahasiswa",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Suarakan permasalahan kampus anda secara terus kepada barisan kepimpinan MPP",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Summary Metric Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard(
                label = "Dalam Semakan",
                count = pendingCount.toString(),
                bg = MaterialTheme.colorScheme.secondaryContainer,
                fg = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = "Sedang Dibaiki",
                count = inProgressCount.toString(),
                bg = MaterialTheme.colorScheme.errorContainer,
                fg = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                label = "Selesai",
                count = resolvedCount.toString(),
                bg = MaterialTheme.colorScheme.tertiaryContainer,
                fg = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.weight(1f)
            )
        }

        // Complaint Form
        AduanSection(
            complaints = emptyList(), // only render form here
            onSubmitComplaint = onSubmitComplaint,
            onComplaintClick = onComplaintClick,
            onViewAllClick = {}
        )

        // All Complaints List with Status Filter
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "Senarai Semua Aduan Terkini",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            // Status filter chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Semua", "Dalam Semakan", "Sedang Dibaiki", "Selesai").forEach { statusLabel ->
                    val isSelected = selectedStatusFilter == statusLabel
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier = Modifier.clickable { selectedStatusFilter = statusLabel }
                    ) {
                        Text(
                            text = statusLabel,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            val filteredList = uiState.complaints.filter { comp ->
                when (selectedStatusFilter) {
                    "Dalam Semakan" -> comp.status == ComplaintStatus.PENDING
                    "Sedang Dibaiki" -> comp.status == ComplaintStatus.IN_PROGRESS
                    "Selesai" -> comp.status == ComplaintStatus.RESOLVED
                    else -> true
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (filteredList.isEmpty()) {
                    Text(
                        text = "Tiada aduan dalam kategori ini.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    filteredList.forEach { complaint ->
                        ComplaintTrackerCard(
                            complaint = complaint,
                            onClick = { onComplaintClick(complaint) }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun MetricCard(
    label: String,
    count: String,
    bg: Color,
    fg: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = count, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = fg)
            Text(text = label, fontSize = 10.5.sp, fontWeight = FontWeight.Medium, color = fg)
        }
    }
}
