package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Campus Civic Flow Palette for MPP KPTMKB
val PrimaryDark = Color(0xFF0F172A)
val PrimaryLight = Color(0xFF000000)
val OnPrimary = Color(0xFFFFFFFF)

val SecondaryBlue = Color(0xFF0051D5)
val SecondaryBlueContainer = Color(0xFFDBE1FF)
val OnSecondaryBlueContainer = Color(0xFF00174B)

val TertiaryGreen = Color(0xFF10B981)
val TertiaryGreenLight = Color(0xFF6FFBBE)
val TertiaryGreenContainer = Color(0xFFD1FAE5)
val OnTertiaryGreen = Color(0xFF004D36)
val OnTertiaryGreenContainer = Color(0xFF009668)

val ErrorRed = Color(0xFFBA1A1A)
val ErrorContainer = Color(0xFFFFDAD6)
val OnErrorContainer = Color(0xFF93000A)

// Surfaces (Light)
val SurfaceLight = Color(0xFFF7F9FB)
val SurfaceContainerLowest = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFF2F4F6)
val SurfaceContainer = Color(0xFFECEEF0)
val SurfaceContainerHigh = Color(0xFFE6E8EA)
val SurfaceContainerHighest = Color(0xFFE0E3E5)
val OnSurfaceLight = Color(0xFF191C1E)
val OnSurfaceVariantLight = Color(0xFF45464D)
val OutlineLight = Color(0xFF76777D)
val OutlineVariantLight = Color(0xFFC6C6CD)

// Dark Theme Variants
val SurfaceDark = Color(0xFF111416)
val SurfaceContainerLowestDark = Color(0xFF191C1E)
val SurfaceContainerLowDark = Color(0xFF1D2023)
val SurfaceContainerDark = Color(0xFF222629)
val SurfaceContainerHighDark = Color(0xFF2A2E32)
val SurfaceContainerHighestDark = Color(0xFF33373B)
val OnSurfaceDark = Color(0xFFECEEF0)
val OnSurfaceVariantDark = Color(0xFFC6C6CD)
val OutlineDark = Color(0xFF8F9097)
