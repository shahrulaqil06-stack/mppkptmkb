package com.example.model

data class Announcement(
    val id: String,
    val title: String,
    val description: String,
    val category: String, // PENTING, AKADEMIK, KEBAJIKAN, KEPIMPINAN
    val badgeLabel: String = category,
    val badgeType: BadgeType = BadgeType.PRIMARY,
    val timeOrDateInfo: String,
    val actionText: String = "Lihat Butiran",
    val meritPoints: Int = 0,
    val imageUri: String? = null,
    val detailsUrlOrNotes: String = ""
)

enum class BadgeType {
    ERROR, // Red
    SECONDARY, // Blue
    TERTIARY, // Green
    PRIMARY // Dark Slate
}

data class Complaint(
    val id: String, // e.g., "#ADU-9842"
    val title: String,
    val category: String, // Fasiliti, Akademik, Kebajikan, Hal Ehwal Pelajar, Lain-lain
    val dateSubmitted: String,
    val status: ComplaintStatus,
    val description: String,
    val isAnonymous: Boolean = false,
    val studentName: String = "Pelajar KPTMKB",
    val matricId: String = "KB2309-XXXX",
    val imageUri: String? = null,
    val excoResponse: String? = null,
    val updatedAt: String? = null
)

enum class ComplaintStatus(val label: String) {
    PENDING("Dalam Semakan"),
    IN_PROGRESS("Sedang Dibaiki"),
    RESOLVED("Selesai"),
    REJECTED("Ditolak")
}

data class CampusEvent(
    val id: String,
    val title: String,
    val category: String,
    val monthShort: String,
    val dayNumber: String,
    val dateRange: String,
    val location: String,
    val targetAudience: String,
    val buttonText: String,
    val isVolunteer: Boolean = false,
    val availableSlots: Int = 0,
    val totalSlots: Int = 50,
    val meritPoints: Int = 60,
    val imageUri: String? = null,
    val description: String = "",
    val registeredParticipants: List<String> = emptyList()
)

data class ExcoMember(
    val id: String,
    val name: String,
    val roleTitle: String,
    val portfolio: String,
    val phoneWhatsApp: String,
    val email: String,
    val photoUrl: String,
    val bio: String = ""
)

data class RentalHouse(
    val id: String,
    val title: String,
    val location: String,
    val monthlyRent: String,
    val genderPreference: String, // Lelaki / Perempuan / Campur
    val distanceToCampus: String,
    val amenities: List<String>,
    val contactPhone: String,
    val imageUri: String? = null,
    val description: String
)

data class PaperworkTemplate(
    val id: String,
    val code: String,
    val title: String,
    val department: String,
    val format: String, // Word / PDF
    val description: String,
    val checklist: List<String>
)

data class CounselingBooking(
    val id: String,
    val studentName: String,
    val matricNo: String,
    val counselorName: String,
    val bookingDate: String,
    val timeSlot: String,
    val category: String,
    val notes: String,
    val status: String = "Disahkan"
)

data class AppNotification(
    val id: String,
    val title: String,
    val message: String,
    val timeAgo: String,
    val isRead: Boolean = false,
    val type: String = "INFO" // INFO, ALERT, SUCCESS
)
