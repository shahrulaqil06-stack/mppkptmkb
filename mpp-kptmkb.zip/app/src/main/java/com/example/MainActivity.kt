package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.MppBottomNav
import com.example.ui.components.MppHeader
import com.example.ui.dialogs.ComplaintDetailDialog
import com.example.ui.dialogs.CounselingDialog
import com.example.ui.dialogs.DermasiswaDialog
import com.example.ui.dialogs.EventRegistrationDialog
import com.example.ui.dialogs.ExamScheduleDialog
import com.example.ui.dialogs.ExcoDetailDialog
import com.example.ui.dialogs.McGeneratorDialog
import com.example.ui.dialogs.NotificationsDialog
import com.example.ui.dialogs.RentalDetailDialog
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AduanScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ServicesScreen
import com.example.ui.screens.TakwimScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MppViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MppViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val context = LocalContext.current

            // Toast effect
            LaunchedEffect(uiState.toastMessage) {
                uiState.toastMessage?.let { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    viewModel.clearToast()
                }
            }

            // Android BackHandler
            BackHandler(enabled = uiState.currentTab != 0) {
                viewModel.setTab(0)
            }

            MyApplicationTheme(darkTheme = uiState.isDarkMode) {
                Scaffold(
                    topBar = {
                        MppHeader(
                            uiState = uiState,
                            onToggleDark = { viewModel.toggleDarkMode() },
                            onToggleAdmin = {
                                viewModel.toggleAdminMode()
                                if (!uiState.isAdminMode) {
                                    viewModel.setTab(4)
                                }
                            },
                            onOpenNotifications = { viewModel.setNotificationsOpen(true) },
                            onSearchChange = { viewModel.setSearchQuery(it) }
                        )
                    },
                    bottomBar = {
                        MppBottomNav(
                            selectedTab = uiState.currentTab,
                            onTabSelected = { viewModel.setTab(it) },
                            isAdminMode = uiState.isAdminMode
                        )
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                    ) {
                        when (uiState.currentTab) {
                            0 -> HomeScreen(
                                uiState = uiState,
                                onAnnouncementClick = { ann ->
                                    Toast.makeText(context, "${ann.title}: ${ann.description}", Toast.LENGTH_LONG).show()
                                },
                                onLamegaClick = {
                                    val lamegaEvent = uiState.events.firstOrNull { it.id == "evt-1" }
                                    if (lamegaEvent != null) {
                                        viewModel.openEventDetail(lamegaEvent)
                                    } else {
                                        Toast.makeText(context, "Pendaftaran LAMEGA 2026 dibuka!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onExamScheduleClick = {
                                    viewModel.setExamScheduleOpen(true)
                                },
                                onDermasiswaClick = {
                                    viewModel.setDermasiswaOpen(true)
                                },
                                onMcGeneratorClick = {
                                    viewModel.setMcGeneratorOpen(true)
                                },
                                onCounselingClick = {
                                    viewModel.setCounselingBookingOpen(true)
                                },
                                onRentalClick = {
                                    viewModel.setTab(1) // Jump to Servis directory
                                },
                                onAduanClick = {
                                    viewModel.setTab(2) // Jump to Aduan tab
                                },
                                onPaperworkClick = {
                                    viewModel.setTab(1) // Jump to Servis paperwork
                                },
                                onTakwimClick = {
                                    viewModel.setTab(3) // Jump to Takwim
                                },
                                onSubmitComplaint = { cat, details, anon, img ->
                                    viewModel.submitComplaint(cat, details, anon, img)
                                },
                                onComplaintClick = { comp ->
                                    viewModel.openComplaintDetail(comp)
                                },
                                onViewAllAduanClick = {
                                    viewModel.setTab(2)
                                },
                                onEventClick = { evt ->
                                    viewModel.openEventDetail(evt)
                                },
                                onViewAllEventsClick = {
                                    viewModel.setTab(3)
                                },
                                onExcoClick = { exco ->
                                    viewModel.openExcoDetail(exco)
                                }
                            )

                            1 -> ServicesScreen(
                                uiState = uiState,
                                onMcGeneratorClick = { viewModel.setMcGeneratorOpen(true) },
                                onCounselingClick = { viewModel.setCounselingBookingOpen(true) },
                                onRentalClick = { house -> viewModel.openRentalDetail(house) },
                                onTemplateClick = { template ->
                                    viewModel.openTemplateDetail(template)
                                },
                                onTakwimClick = { viewModel.setTab(3) }
                            )

                            2 -> AduanScreen(
                                uiState = uiState,
                                onSubmitComplaint = { cat, details, anon, img ->
                                    viewModel.submitComplaint(cat, details, anon, img)
                                },
                                onComplaintClick = { comp ->
                                    viewModel.openComplaintDetail(comp)
                                }
                            )

                            3 -> TakwimScreen(
                                uiState = uiState,
                                onEventClick = { evt ->
                                    viewModel.openEventDetail(evt)
                                }
                            )

                            4 -> AdminScreen(
                                uiState = uiState,
                                onToggleAdminMode = { viewModel.toggleAdminMode() },
                                onUpdateComplaintStatus = { id, status, note ->
                                    viewModel.updateComplaintStatus(id, status, note)
                                },
                                onDeleteComplaint = { id -> viewModel.deleteComplaint(id) },
                                onAddAnnouncement = { title, desc, cat, badge, time, act, merit, img, details ->
                                    viewModel.addAnnouncement(title, desc, cat, badge, time, act, merit, img, details)
                                },
                                onDeleteAnnouncement = { id -> viewModel.deleteAnnouncement(id) },
                                onAddEvent = { title, cat, month, day, dateRange, loc, aud, btn, vol, slots, merit, img, desc ->
                                    viewModel.addEvent(title, cat, month, day, dateRange, loc, aud, btn, vol, slots, merit, img, desc)
                                },
                                onDeleteEvent = { id -> viewModel.deleteEvent(id) },
                                onAddRentalHouse = { title, loc, rent, gen, dist, amen, phone, img, desc ->
                                    viewModel.addRentalHouse(title, loc, rent, gen, dist, amen, phone, img, desc)
                                },
                                onDeleteRentalHouse = { id -> viewModel.deleteRentalHouse(id) }
                            )
                        }
                    }

                    // Dialogs & Modals Overlays
                    uiState.activeComplaintDetail?.let { comp ->
                        ComplaintDetailDialog(
                            complaint = comp,
                            onDismiss = { viewModel.closeComplaintDetail() }
                        )
                    }

                    uiState.activeEventDetail?.let { evt ->
                        EventRegistrationDialog(
                            event = evt,
                            onDismiss = { viewModel.closeEventDetail() },
                            onRegister = { name, matric ->
                                viewModel.registerEvent(evt.id, name, matric)
                            }
                        )
                    }

                    uiState.activeExcoDetail?.let { exco ->
                        ExcoDetailDialog(
                            exco = exco,
                            onDismiss = { viewModel.closeExcoDetail() }
                        )
                    }

                    uiState.activeRentalDetail?.let { house ->
                        RentalDetailDialog(
                            house = house,
                            onDismiss = { viewModel.closeRentalDetail() }
                        )
                    }

                    if (uiState.isMcGeneratorOpen) {
                        McGeneratorDialog(
                            onDismiss = { viewModel.setMcGeneratorOpen(false) },
                            onGenerate = { name, mat, prog, dates, reason, lec, code ->
                                viewModel.generateMcLetter(name, mat, prog, dates, reason, lec, code)
                            },
                            generatedLetter = uiState.generatedLetterContent,
                            onClearLetter = { viewModel.clearGeneratedLetter() }
                        )
                    }

                    if (uiState.isCounselingBookingOpen) {
                        CounselingDialog(
                            onDismiss = { viewModel.setCounselingBookingOpen(false) },
                            onBook = { counselor, date, time, cat, notes ->
                                viewModel.bookCounseling(counselor, date, time, cat, notes)
                            }
                        )
                    }

                    if (uiState.isDermasiswaOpen) {
                        DermasiswaDialog(
                            onDismiss = { viewModel.setDermasiswaOpen(false) },
                            onSubmit = { income, reason ->
                                Toast.makeText(context, "Permohonan Dermasiswa telah diserahkan ke Exco Kebajikan", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    if (uiState.isExamScheduleOpen) {
                        ExamScheduleDialog(
                            onDismiss = { viewModel.setExamScheduleOpen(false) }
                        )
                    }

                    if (uiState.isNotificationsOpen) {
                        NotificationsDialog(
                            notifications = uiState.notifications,
                            onDismiss = { viewModel.setNotificationsOpen(false) },
                            onMarkAllRead = { viewModel.markAllNotificationsRead() }
                        )
                    }
                }
            }
        }
    }
}
