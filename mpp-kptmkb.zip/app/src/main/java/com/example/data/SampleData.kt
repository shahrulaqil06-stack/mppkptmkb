package com.example.data

import com.example.model.Announcement
import com.example.model.AppNotification
import com.example.model.BadgeType
import com.example.model.CampusEvent
import com.example.model.Complaint
import com.example.model.ComplaintStatus
import com.example.model.ExcoMember
import com.example.model.PaperworkTemplate
import com.example.model.RentalHouse

object SampleData {
    val initialAnnouncements = listOf(
        Announcement(
            id = "ann-1",
            title = "Pendaftaran Program LAMEGA 2026",
            description = "Program kepimpinan terbesar tahunan KPTMKB. Tarikh Tutup: 28 Feb 2026.",
            category = "PENTING",
            badgeType = BadgeType.ERROR,
            timeOrDateInfo = "5 Hari Lagi",
            actionText = "Daftar Sekarang",
            meritPoints = 120,
            detailsUrlOrNotes = "Latihan Kepimpinan Mahasiswa Generasi Berwibawa (LAMEGA) bertempat di Kem Rekreasi Rimba Teladas."
        ),
        Announcement(
            id = "ann-2",
            title = "Hebahan Cuti & Peperiksaan Akhir",
            description = "Jadual rasmi cuti pertengahan semester dan tarikh penting peperiksaan akhir Semester 2.",
            category = "AKADEMIK",
            badgeType = BadgeType.SECONDARY,
            timeOrDateInfo = "15 Mac - 22 Mac",
            actionText = "Semak Jadual",
            meritPoints = 0,
            detailsUrlOrNotes = "Dikeluarkan oleh Bahagian Hal Ehwal Akademik (BHEA) KPTM Kota Bharu. Pastikan tiada yuran tertunggak."
        ),
        Announcement(
            id = "ann-3",
            title = "Skim Dermasiswa Cakna Mahasiswa 2026",
            description = "Bantuan sara hidup & zakat khas pelajar kurang berkemampuan KPTMKB sesi ini.",
            category = "KEBAJIKAN",
            badgeType = BadgeType.TERTIARY,
            timeOrDateInfo = "B40 & Asnaf",
            actionText = "Mohon Bantuan",
            meritPoints = 0,
            detailsUrlOrNotes = "Ditaja di bawah Tabung Kebajikan Mahasiswa MPP & Pusat Zakat MAIK. Terbuka kepada semua semester aktif."
        )
    )

    val initialComplaints = listOf(
        Complaint(
            id = "#ADU-9842",
            title = "AC Bilik Kuliah 3.4",
            category = "Fasiliti",
            dateSubmitted = "22 Feb 2026",
            status = ComplaintStatus.IN_PROGRESS,
            description = "Hawa dingin Bilik Kuliah 3.4 bocor dan mengeluarkan bunyi bising semasa sesi syarahan petang.",
            isAnonymous = false,
            studentName = "Amirul Hakim",
            matricId = "KB2401-2041",
            excoResponse = "Juruteknik fasiliti kolej telah dihubungi dan alat ganti kompressor sedang dipasang.",
            updatedAt = "23 Feb 2026, 11:30 AM"
        ),
        Complaint(
            id = "#ADU-9810",
            title = "Kebajikan Banjir Pelajar",
            category = "Kebajikan",
            dateSubmitted = "20 Feb 2026",
            status = ComplaintStatus.RESOLVED,
            description = "Bantuan kecemasan kit makanan & pemindahan untuk 8 orang pelajar rumah sewa Tanjung Chat yang terjejas banjir kilat.",
            isAnonymous = true,
            excoResponse = "Exco Kebajikan bersama Unit Kenderaan KPTMKB telah menghantar bantuan kit kering dan memindahkan pelajar ke asrama sementara kolej.",
            updatedAt = "21 Feb 2026, 04:15 PM"
        ),
        Complaint(
            id = "#ADU-9788",
            title = "Jadual Kuliah Bertindih",
            category = "Akademik",
            dateSubmitted = "18 Feb 2026",
            status = ComplaintStatus.PENDING,
            description = "Subjek MKT2013 dan ITB2043 untuk Seksyen 2 bertindih pada hari Selasa jam 10:00 pagi.",
            isAnonymous = false,
            studentName = "Nur Fasihah",
            matricId = "KB2307-1189",
            excoResponse = "Wakil Exco Akademik telah membawa isu ini ke mesyuarat penyelarasan jadual BHEA bersama Penyelaras Kursus.",
            updatedAt = "19 Feb 2026, 09:00 AM"
        )
    )

    val initialEvents = listOf(
        CampusEvent(
            id = "evt-1",
            title = "IFECT 2026 Challenge",
            category = "Inovasi Kampus",
            monthShort = "MAC",
            dayNumber = "05",
            dateRange = "5 - 7 Mac 2026",
            location = "Dewan Bunga Raya",
            targetAudience = "Semua Pelajar",
            buttonText = "Daftar Peserta",
            isVolunteer = false,
            availableSlots = 40,
            totalSlots = 60,
            meritPoints = 80,
            description = "Pertandingan inovasi teknologi pintar peringkat kolej terbuka kepada semua program pengajian KPTMKB."
        ),
        CampusEvent(
            id = "evt-2",
            title = "Rakan Muda Parlimen KB",
            category = "Khidmat Komuniti",
            monthShort = "MAC",
            dayNumber = "14",
            dateRange = "14 Mac 2026",
            location = "Pantai Cahaya Bulan",
            targetAudience = "Sukarelawan Mahasiswa",
            buttonText = "Daftar Sukarelawan",
            isVolunteer = true,
            availableSlots = 12,
            totalSlots = 45,
            meritPoints = 50,
            description = "Program pembersihan pesisir pantai dan penyerahan sumbangan pek ramadhan bersama komuniti setempat."
        ),
        CampusEvent(
            id = "evt-3",
            title = "Misi CSR Mahasiswa Hatyai",
            category = "Misi Antarabangsa",
            monthShort = "APR",
            dayNumber = "02",
            dateRange = "2 - 4 April 2026",
            location = "Selatan Thailand",
            targetAudience = "Pelajar Semester 3 - 6",
            buttonText = "Maklumat Lanjut",
            isVolunteer = false,
            availableSlots = 25,
            totalSlots = 30,
            meritPoints = 150,
            description = "Misi khidmat bakti antarabangsa melibatkan perkongsian ilmu teknologi dan bahasa bersama sekolah angkat."
        )
    )

    val initialExcos = listOf(
        ExcoMember(
            id = "exco-1",
            name = "Wan Muhammad Danial",
            roleTitle = "Yang di-Pertua (YDP)",
            portfolio = "Kepimpinan & Perhubungan Luar",
            phoneWhatsApp = "601123456789",
            email = "ydp.mpp@kptm.edu.my",
            photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCSR5Wu62blmNIMzrGOuMnZM69NBQ0xK67gg1nytegRNXBgLA6ep7JAf3MBvqoyoBZnW1CxshktkrbSkKIBkzZHK8sgBEGjo-DFApxUBbJ2fwwCJlC-mmx_7UkQ7YCGhLbnzPSlD4BuP5FKXBQrub3SZOuMKIjUqxakXKo7Fn7s0VRtVf3CpShdcEm-OYrkKv-5zLOw5XsHlRQgLPiA3KqwjUB0e0QQNxuXIKL5yhzh",
            bio = "Mahasiswa Diploma Pengurusan Perniagaan semester akhir. Berdedikasi memimpin kebajikan dan suara mahasiswa KPTM Kota Bharu ke arah kecemerlangan holistik."
        ),
        ExcoMember(
            id = "exco-2",
            name = "Nur Sarah Batrisyia",
            roleTitle = "Timbalan YDP",
            portfolio = "Hal Ehwal Wanita & Kampus",
            phoneWhatsApp = "601198765432",
            email = "tydp.mpp@kptm.edu.my",
            photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuDjCbni_RJgOuWiaBoXT9vvBpH3HC-VhW7w5eI3I4puPlw_9PiUdQAxOdPaC4jR_iGFut4H5wf7f4Jrq9sfeBYBspnEBK2IfRiLVaODorRivn5-bUrU4gBZuRVyLDsf9vpLPCzNZ_Z3-Z15SHhJI9h1J7inHYiA3azESm59vmb-l4OsVFgEOFFLRX2YqMz6X61p67H4ZfBSEWF4K3IoO0q_1KQidHBVdNkUWYjoMGSf",
            bio = "Mahasiswi Diploma Teknologi Maklumat. Mengkhususkan fokus kepada keselamatan kampus, aktiviti siswi, serta kelestarian fasiliti asrama."
        ),
        ExcoMember(
            id = "exco-3",
            name = "Muhammad Faris Haikal",
            roleTitle = "Setiausaha Kehormat",
            portfolio = "Pentadbiran & Dokumentasi BHEA",
            phoneWhatsApp = "601134567890",
            email = "su.mpp@kptm.edu.my",
            photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAqeO-Ey1a-W2aWsC5txDjjCQU7yrHz1eLv0Hs88v0uJdxX8RjNa4PxlDln69yUt4ehMiCStajYAb7hy8ccg2oOk_UHQAhPmdvBFn6Qs2v8LwSdz9UdeFtp8TbGcn1NrdD9jCxLK2JFqOJFdkYQnhY4KBTZY7WktOzNp3vCdyuX2pJU8ATaSbyJPnYidPs-BNcVggwKMqcuwKvOWWXgYdA6rL7zDnKGBd4ywuy6g5gY",
            bio = "Menguruskan surat-menyurat rasmi kolej, minit mesyuarat, serta pengesahan kertas kerja kelab dan persatuan mahasiswa."
        ),
        ExcoMember(
            id = "exco-4",
            name = "Ahmad Zulfiqar",
            roleTitle = "Exco Kebajikan & Fasiliti",
            portfolio = "Rumah Sewa & Bantuan Cakna",
            phoneWhatsApp = "601145678901",
            email = "kebajikan.mpp@kptm.edu.my",
            photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuAkzN3LlEomemJ2B10UzMTVB-_LilgIedS9slyXVxxQTIDriRQmDj7hao-pgu_skAs7m7XMZVYC7csxia8VXUPi1zszM-P1_Qy_GQQTJuAXo2y3c4nOhx3b7IgpW8KACOBKPMnYsUonQpkl7ncgUTc7gclqUoVp5QNQsRJuj6sQWGtLqli5C7G4JVCSSXIzF0gYuTShK4_tdR-zRDI9IMJsrsoB5S8KMwOTTNHFfQhg",
            bio = "Menyelaras direktori rumah sewa selamat, penganjuran agihan makanan Food Bank MPP, dan penyelesaian aduan fasiliti harian."
        ),
        ExcoMember(
            id = "exco-5",
            name = "Siti Aisyah Razak",
            roleTitle = "Exco Akademik & Kerjaya",
            portfolio = "Aduan Jadual & Bengkel Kerjaya",
            phoneWhatsApp = "601156789012",
            email = "akademik.mpp@kptm.edu.my",
            photoUrl = "https://lh3.googleusercontent.com/aida-public/AB6AXuCAm51bNnHxwnxRxng9wJ-DWkgZA-jUq740Di62INo-6L5V8R88kv5ovcZahxw7zyyhDMAQVdQeCBuwqfarA7SOahCxsRP_evojX85vTL8SEnEBcJjpNKCXlJciDp6aQhxhFZGYirJKdlkrMG5luE39Hx0kY7wO65tz45FsosHQ-euuvSfM2xWlvdB3S0wiRUZvx9YeUEMGsn6ei29USqBhrRN5wFkeXOdfipj7NeUl",
            bio = "Membantu pelajar dalam urusan semakan gred, rayuan peperiksaan, bengkel penulisan resume, dan latihan industri."
        )
    )

    val initialRentalHouses = listOf(
        RentalHouse(
            id = "house-1",
            title = "Rumah Teres Harmoni Pengkalan Chepa",
            location = "Taman Sari, Pengkalan Chepa (500m dari KPTMKB)",
            monthlyRent = "RM 180 / orang",
            genderPreference = "Lelaki",
            distanceToCampus = "5 minit berjalan kaki",
            amenities = listOf("WiFi Laju", "Peti Ais", "Mesin Basuh", "Katil & Tilam", "Dapur Lengkap"),
            contactPhone = "019-9123456",
            description = "Rumah teres 4 bilik tidur dan 3 bilik air. Suasana tenang berhampiran kedai runcit dan kedai makan."
        ),
        RentalHouse(
            id = "house-2",
            title = "Banglo Siswi Kubang Kerian",
            location = "Jalan Sultan Yahya Petra, Kubang Kerian",
            monthlyRent = "RM 220 / orang",
            genderPreference = "Perempuan",
            distanceToCampus = "10 minit berkereta / bas",
            amenities = listOf("Aircond", "Pagar Keselamatan", "WiFi Unifi", "Mesin Basuh", "Water Heater"),
            contactPhone = "017-8899123",
            description = "Khas untuk mahasiswi KPTM. Rumah berpagar dengan kawalan grill keselamatan dan parking luas."
        ),
        RentalHouse(
            id = "house-3",
            title = "Apartment Vista Tanjung Chat",
            location = "Tanjung Chat, Kota Bharu",
            monthlyRent = "RM 160 / orang",
            genderPreference = "Lelaki",
            distanceToCampus = "7 minit motosikal",
            amenities = listOf("Mesin Basuh", "Meja Belajar", "Almari Baju", "Dapur Gas"),
            contactPhone = "013-7744112",
            description = "Unit tingkat 2 selesa, sewa termasuk utiliti asas, berdekatan masjid dan dobi layan diri."
        )
    )

    val initialTemplates = listOf(
        PaperworkTemplate(
            id = "doc-1",
            code = "BHEA.TT.08.PdP.02",
            title = "Borang Permohonan Cuti Kuliah & Gantian Kelas",
            department = "Bahagian Hal Ehwal Akademik",
            format = "PDF & DOCX",
            description = "Digunakan oleh mahasiswa yang tidak dapat menghadiri kuliah atau peperiksaan kerana MC atau kecemasan rasmi.",
            checklist = listOf("Lampirkan Sijil Sakit (MC) asal atau surat kematian waris", "Dapatkan tandatangan pensyarah kursus", "Hantar ke kaunter BHEA dalam tempoh 48 jam")
        ),
        PaperworkTemplate(
            id = "doc-2",
            code = "HEP.KKP.01.2026",
            title = "Format Kertas Kerja Rasmi Aktiviti & Kelab Pelajar",
            department = "Hal Ehwal Pelajar (HEP)",
            format = "DOCX",
            description = "Templat piawai permohonan penganjuran aktiviti, peruntukan bajet kewangan, dan pelepasan kuliah rasmi.",
            checklist = listOf("Sertakan objektif SMART dan hasil pembelajaran", "Belanjawan terperinci dengan sebut harga", "Surat sokongan Penasihat Kelab")
        ),
        PaperworkTemplate(
            id = "doc-3",
            code = "MPP.BANTUAN.CAKNA",
            title = "Borang Permohonan Skim Bantuan Cakna Mahasiswa",
            department = "Exco Kebajikan MPP",
            format = "PDF",
            description = "Permohonan bantuan sara hidup segera, kupon makanan asnaf, dan bantuan bencana alam.",
            checklist = listOf("Salinan slip gaji ibu bapa / pengesahan pendapatan Penghulu", "Salinan kad matrik pelajar", "Slip keputusan peperiksaan terkini")
        )
    )

    val initialNotifications = listOf(
        AppNotification(
            id = "notif-1",
            title = "Pendaftaran LAMEGA 2026 Dibuka!",
            message = "Rebut 120 Merit HEP sebelum pendaftaran ditutup pada 28 Feb 2026.",
            timeAgo = "10 minit lepas",
            type = "ALERT"
        ),
        AppNotification(
            id = "notif-2",
            title = "Status Aduan #ADU-9842 Dikemaskini",
            message = "AC Bilik Kuliah 3.4 kini berstatus: Sedang Dibaiki oleh juruteknik kolej.",
            timeAgo = "1 jam lepas",
            type = "INFO"
        ),
        AppNotification(
            id = "notif-3",
            title = "Bantuan Banjir Disalurkan",
            message = "8 pelajar rumah sewa Tanjung Chat telah selamat dipindahkan dan menerima pek kebajikan.",
            timeAgo = "Semalam",
            type = "SUCCESS"
        )
    )
}
